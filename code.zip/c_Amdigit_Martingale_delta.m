function delta = c_Amdigit_Martingale_delta(K,S0,r,sigma,T)
%c_AmdigitCall_Martingale_delta calculate delta by analytical formula
%derived by martingale method
%   �˴���ʾ��ϸ˵��
alpha=@(r,sigma)r-sigma.^2/2;
beta=@(r,sigma)sqrt(alpha(r,sigma).^2+2.*sigma.^2.*r);
x_plus=@(K,S0,r,sigma,t)(log(K./S0)+beta(r,sigma).*t)./(sigma.*sqrt(t));
x_minus=@(K,S0,r,sigma,t)(log(K./S0)-beta(r,sigma).*t)./(sigma.*sqrt(t));
delta=-K./S0.^2.*(alpha(r,sigma)+beta(r,sigma))./sigma.^2.*(K./S0).^((alpha(r,sigma)+beta(r,sigma))./sigma.^2-1).*cdf('norm',-x_plus(K,S0,r,sigma,T),0,1)+ ...
    (K./S0).^((alpha(r,sigma)+beta(r,sigma))./sigma.^2).*pdf('norm',-x_plus(K,S0,r,sigma,T),0,1)./(sigma.*sqrt(T).*S0)- ...
    K./S0.^2.*(alpha(r,sigma)-beta(r,sigma))./sigma.^2.*(K./S0).^((alpha(r,sigma)-beta(r,sigma))./sigma.^2-1).*cdf('norm',-x_minus(K,S0,r,sigma,T),0,1)+ ...
    (K./S0).^((alpha(r,sigma)-beta(r,sigma))./sigma.^2).*pdf('norm',-x_minus(K,S0,r,sigma,T),0,1)./(sigma.*sqrt(T).*S0);
end

