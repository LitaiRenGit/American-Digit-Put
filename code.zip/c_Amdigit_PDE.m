function price = c_Amdigit_PDE(K,S0,r,sigma,T)
%c_AmdigitCall_PDE American Digital Call price by PDE
%   �˴���ʾ��ϸ˵��
k=r./(sigma.^2/2);
lambda_plus=1;lambda_minus=-k;
alpha=(1-k)./2;beta=-((1-k).^2/4+k);
d_plus=@(K,S0,r,sigma,t)(log(S0./K)+sigma^2*sqrt(-beta).*t)./(sigma.*sqrt(t));
d_minus=@(K,S0,r,sigma,t)(log(S0./K)-sigma^2*sqrt(-beta).*t)./(sigma.*sqrt(t));
price=(S0./K).^lambda_plus.*cdf('norm',d_plus(K,S0,r,sigma,T),0,1)+(S0./K).^lambda_minus.*cdf('norm',d_minus(K,S0,r,sigma,T),0,1);
end

